package ProductOperationsImplementor;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import db_config.DB_Connection;
import model.ProductPojo;
import operations.ProductOperations;

public class ProductOperationImplementor implements ProductOperations {

    @Override
    public void add(ProductPojo pojo) {
        System.out.println("Executing 'add' method...");

        try (Connection conn = DB_Connection.getConnection();
             CallableStatement stmt = conn.prepareCall("{CALL place_order(?, ?, ?, ?)}")) {

            System.out.println("Calling stored procedure 'place_order' with: "
                    + "product_id = " + pojo.getProduct_id() + ", "
                    + "consumer_port_id = " + pojo.getConsumer_port_id() + ", "
                    + "quantity = " + pojo.getQuantity() + ", "
                    + "order_date = " + pojo.getOrder_date());

            stmt.setInt(1, pojo.getProduct_id());
            stmt.setInt(2, pojo.getConsumer_port_id());
            stmt.setInt(3, pojo.getQuantity());
            stmt.setDate(4, pojo.getOrder_date());

            stmt.execute();
            System.out.println("✅ Stored procedure 'place_order' executed successfully.");

        } catch (SQLException e) {
            System.err.println("❌ Error in executing stored procedure 'place_order': " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    public void update(ProductPojo pojo) {
        Connection conn = null;
        CallableStatement cstmt = null;

        try {
            conn = DB_Connection.getConnection();
            cstmt = conn.prepareCall("{call update_order_status(?, ?, ?)}");

            cstmt.setInt(1, pojo.getOrder_id());
            cstmt.setString(2, pojo.getUpdateStatusKey());  // e.g., "shipped"
            cstmt.setBoolean(3, pojo.getUpdateStatusValue());  // e.g., true or false

            cstmt.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (cstmt != null) cstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    @Override
    public void delete(ProductPojo pojo) {
        System.out.println("Executing 'delete' method...");

        try (Connection conn = DB_Connection.getConnection();
             CallableStatement stmt = conn.prepareCall("{CALL cancel_order(?)}")) {

            stmt.setInt(1, pojo.getOrder_id());
            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("✅ Order deleted successfully.");
            } else {
                System.out.println("⚠️ No order deleted. It may already be shipped or not exist.");
            }

        } catch (SQLException e) {
            System.err.println("❌ Error in executing stored procedure 'cancel_order': " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    public List<ProductPojo> show() {
        List<ProductPojo> list = new ArrayList<>();

        try (Connection conn = DB_Connection.getConnection();
             CallableStatement cs = conn.prepareCall("{CALL get_all_orders()}");
             ResultSet rs = cs.executeQuery()) {

            while (rs.next()) {
                ProductPojo p = new ProductPojo();
                p.setOrder_id(rs.getInt("order_id"));
                p.setProduct_id(rs.getInt("product_id"));
                p.setConsumer_port_id(rs.getInt("consumer_port_id"));
                p.setQuantity(rs.getInt("quantity"));
                p.setOrder_date(rs.getDate("order_date"));
                p.setOrder_placed(rs.getBoolean("order_placed"));
                p.setShipped(rs.getBoolean("shipped"));
                p.setOut_for_delivery(rs.getBoolean("out_for_delivery"));
                p.setDelivered(rs.getBoolean("delivered"));
                list.add(p);
            }

        } catch (Exception e) {
            System.err.println("❌ Error in 'get_all_orders': " + e.getMessage());
            e.printStackTrace();
        }

        return list;
    }

    public ProductPojo getOrderStatus(int orderId) {
        ProductPojo p = new ProductPojo();

        try (Connection conn = DB_Connection.getConnection();
             CallableStatement cs = conn.prepareCall("{CALL get_order_status(?)}")) {

            cs.setInt(1, orderId);

            try (ResultSet rs = cs.executeQuery()) {
                if (rs.next()) {
                    p.setOrder_id(orderId);
                    p.setOrder_date(rs.getDate("order_date"));
                    p.setOrder_placed(rs.getBoolean("order_placed"));
                    p.setShipped(rs.getBoolean("shipped"));
                    p.setOut_for_delivery(rs.getBoolean("out_for_delivery"));
                    p.setDelivered(rs.getBoolean("delivered"));
                } else {
                    System.out.println("[INFO] No status found for order_id " + orderId);
                }
            }

        } catch (Exception e) {
            System.err.println("❌ Error in 'getOrderStatus': " + e.getMessage());
            e.printStackTrace();
        }

        return p;
    }

    public List<ProductPojo> searchByOrderId(int orderId) {
        List<ProductPojo> list = new ArrayList<>();

        try (Connection conn = DB_Connection.getConnection();
             CallableStatement cs = conn.prepareCall("{CALL get_order_status(?)}")) {

            cs.setInt(1, orderId);

            try (ResultSet rs = cs.executeQuery()) {
                while (rs.next()) {
                    ProductPojo p = new ProductPojo();
                    p.setOrder_id(orderId);
                    p.setProduct_id(rs.getInt("product_id"));
                    p.setConsumer_port_id(rs.getInt("consumer_port_id"));
                    p.setQuantity(rs.getInt("quantity"));
                    p.setOrder_date(rs.getDate("order_date"));
                    p.setOrder_placed(rs.getBoolean("order_placed"));
                    p.setShipped(rs.getBoolean("shipped"));
                    p.setOut_for_delivery(rs.getBoolean("out_for_delivery"));
                    p.setDelivered(rs.getBoolean("delivered"));
                    list.add(p);
                }
            }

        } catch (Exception e) {
            System.err.println("❌ Error in 'searchByOrderId': " + e.getMessage());
            e.printStackTrace();
        }

        return list;
    }
    
    public void updateOrderStatus(int orderId, String statusName, boolean statusValue) {
        System.out.println("Executing dynamic order status update...");
        try (Connection conn = DB_Connection.getConnection();
             CallableStatement stmt = conn.prepareCall("{CALL update_order_status(?, ?, ?)}")) {

            stmt.setInt(1, orderId);
            stmt.setString(2, statusName);
            stmt.setBoolean(3, statusValue);

            stmt.execute();
            System.out.println("Order status updated successfully.");

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Failed to update order status.");
        }
    }

}

