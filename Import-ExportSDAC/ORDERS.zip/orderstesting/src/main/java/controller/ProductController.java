package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ProductOperationsImplementor.ProductOperationImplementor;
import model.ProductPojo;

@WebServlet("/ProductController")
public class ProductController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        ProductOperationImplementor ops = new ProductOperationImplementor();
        try {
            String action = req.getParameter("action");

            if ("search_status".equalsIgnoreCase(action)) {
                String searchIdStr = req.getParameter("search_order_id");
                if (searchIdStr != null && !searchIdStr.trim().isEmpty()) {
                    int searchOrderId = Integer.parseInt(searchIdStr.trim());
                    List<ProductPojo> searchedOrders = ops.searchByOrderId(searchOrderId);
                    req.setAttribute("ordersList", searchedOrders);
                } else {
                    List<ProductPojo> orders = ops.show();
                    req.setAttribute("ordersList", orders);
                }
            } else {
                // Default: show all orders
                List<ProductPojo> orders = ops.show();
                req.setAttribute("ordersList", orders);
            }

            // Move successMessage from session to request if present
            String successMessage = (String) req.getSession().getAttribute("successMessage");
            if (successMessage != null) {
                req.setAttribute("successMessage", successMessage);
                req.getSession().removeAttribute("successMessage");
            }

            RequestDispatcher rd = req.getRequestDispatcher("product_crud.jsp");
            rd.forward(req, resp);
        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("error", "Error processing request: " + e.getMessage());
            req.getRequestDispatcher("product_crud.jsp").forward(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String flag = req.getParameter("action");
        ProductOperationImplementor ops = new ProductOperationImplementor();

        try {
            // INSERT
            if ("insertnullnullnull".equalsIgnoreCase(flag)) {
                ProductPojo pojo = new ProductPojo();
                pojo.setProduct_id(Integer.parseInt(req.getParameter("product_id")));
                pojo.setConsumer_port_id(Integer.parseInt(req.getParameter("consumer_port_id")));
                pojo.setQuantity(Integer.parseInt(req.getParameter("quantity")));
                pojo.setOrder_date(new java.sql.Date(System.currentTimeMillis()));
                ops.add(pojo);

                req.getSession().setAttribute("successMessage", "Order placed successfully!");
            }

            // UPDATE STATUS ONLY
            else if ("nullupdatenullnull".equalsIgnoreCase(flag)) {
                int orderId = Integer.parseInt(req.getParameter("order_id"));
                String statusName = req.getParameter("status_name");  // e.g. "shipped", "out_for_delivery", "delivered"
                boolean statusValue = Boolean.parseBoolean(req.getParameter("status_value")); // expected: "true" or "false"

                ProductPojo pojo = new ProductPojo();
                pojo.setOrder_id(orderId);
                pojo.setUpdateStatusKey(statusName);
                pojo.setUpdateStatusValue(statusValue); // Make sure this setter exists

                ops.update(pojo);

                req.getSession().setAttribute("successMessage", "Order status updated successfully!");
            }

            // DELETE
            else if ("nullnulldeletenull".equalsIgnoreCase(flag)) {
                ProductPojo pojo = new ProductPojo();
                pojo.setOrder_id(Integer.parseInt(req.getParameter("order_id")));
                ops.delete(pojo);

                req.getSession().setAttribute("successMessage", "Order deleted successfully!");
            }

            // Redirect to GET after any operation (Post-Redirect-Get pattern)
            resp.sendRedirect("ProductController?action=show");

        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("error", "Operation failed: " + e.getMessage());
            RequestDispatcher rd = req.getRequestDispatcher("product_crud.jsp");
            rd.forward(req, resp);
        }
    }
}
