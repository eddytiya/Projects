package db_config;

import java.sql.Connection;
import java.sql.DriverManager;

public class DB_Connection {
    public static Connection getConnection() {
        Connection con = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/Testorders", // ⚠️ Replace with correct DB name
                "root", 
                "root" // ⚠️ Replace with the password you're entering in the terminal
            );
        } catch (Exception e) {
            System.out.println("Connection failed.");
            e.printStackTrace();
        }
        return con;
    }
}