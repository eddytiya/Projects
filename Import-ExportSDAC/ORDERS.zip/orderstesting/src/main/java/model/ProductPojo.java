package model;

import java.sql.Date;
import java.util.List;

import ProductOperationsImplementor.ProductOperationImplementor;

public class ProductPojo {
    private int order_id;
    private int product_id;
    private int consumer_port_id;
    private int quantity;
    private Date order_date;
    private boolean order_placed;
    private boolean shipped;
    private boolean out_for_delivery;
    private boolean delivered;

    // Fields for dynamic status update
    private String updateStatusKey;
    private boolean updateStatusValue;

    // Getters and Setters
    public int getOrder_id() {
        return order_id;
    }
    public void setOrder_id(int order_id) {
        this.order_id = order_id;
    }

    public int getProduct_id() {
        return product_id;
    }
    public void setProduct_id(int product_id) {
        this.product_id = product_id;
    }

    public int getConsumer_port_id() {
        return consumer_port_id;
    }
    public void setConsumer_port_id(int consumer_port_id) {
        this.consumer_port_id = consumer_port_id;
    }

    public int getQuantity() {
        return quantity;
    }
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public Date getOrder_date() {
        return order_date;
    }
    public void setOrder_date(Date order_date) {
        this.order_date = order_date;
    }

    public boolean isOrder_placed() {
        return order_placed;
    }
    public void setOrder_placed(boolean order_placed) {
        this.order_placed = order_placed;
    }

    public boolean isShipped() {
        return shipped;
    }
    public void setShipped(boolean shipped) {
        this.shipped = shipped;
    }

    public boolean isOut_for_delivery() {
        return out_for_delivery;
    }
    public void setOut_for_delivery(boolean out_for_delivery) {
        this.out_for_delivery = out_for_delivery;
    }

    public boolean isDelivered() {
        return delivered;
    }
    public void setDelivered(boolean delivered) {
        this.delivered = delivered;
    }

    public String getUpdateStatusKey() {
        return updateStatusKey;
    }
    public void setUpdateStatusKey(String updateStatusKey) {
        this.updateStatusKey = updateStatusKey;
    }

    public boolean getUpdateStatusValue() {
        return updateStatusValue;
    }
    public void setUpdateStatusValue(boolean updateStatusValue) {
        this.updateStatusValue = updateStatusValue;
    }

    // CRUD helper methods
    public void addProduct(ProductPojo pojo) {
        new ProductOperationImplementor().add(pojo);
    }
    public void updateProduct(ProductPojo pojo) {
        new ProductOperationImplementor().update(pojo);
    }
    public void deleteProduct(ProductPojo pojo) {
        new ProductOperationImplementor().delete(pojo);
    }
    public List<ProductPojo> showProduct() {
        return new ProductOperationImplementor().show();
    }
}
