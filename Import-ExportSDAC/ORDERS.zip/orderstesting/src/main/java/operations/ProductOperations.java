package operations;

import java.util.List;

import model.ProductPojo;

public interface ProductOperations {
	void add(ProductPojo pojo);
	void update(ProductPojo pojo);
	void delete(ProductPojo pojo) throws Exception;
	  List<ProductPojo> show();

}
