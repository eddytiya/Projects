<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.List" %>
<%@ page import="model.ProductPojo" %>
<%
    String action = request.getParameter("action");
    if (action == null) {
        response.sendRedirect("ProductController?action=show");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Order Form</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
<style>
    body {
        font-family: 'Inter', sans-serif;
        background-color: #f4f6f8;
        margin: 0;
        padding: 0;
    }

    h2 {
        background-color: #4A90E2;
        color: white;
        padding: 20px;
        margin: 0;
        border-bottom: 3px solid #357ABD;
        text-align: center;
    }

    table {
        border-collapse: collapse;
        width: 95%;
        margin: 30px auto;
        background-color: white;
        font-family: 'Inter', sans-serif;
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        border-radius: 8px;
        overflow: hidden;
    }

    th {
        background-color: #d6e6fb;
        color: black;
        padding: 12px;
        font-weight: bold;
        text-align: center;
    }

    td {
        text-align: center;
        padding: 12px;
    }

    tr:nth-child(even) {
        background-color: #f9f9f9;
    }

    tr:nth-child(odd) {
        background-color: #ffffff;
    }

    tr:hover {
        background-color: #f0f4ff;
    }

    .edit-btn {
        background-color: #FFC107;
        border-radius: 50%;
        border: none;
        padding: 10px;
        font-size: 16px;
        cursor: pointer;
        margin: 0 4px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.2);
    }

    .edit-btn i {
        color: black;
    }

    .delete-btn {
        background-color: white;
        border: 2px solid black;
        border-radius: 4px;
        padding: 10px;
        cursor: pointer;
        margin: 0 4px;
    }

    .delete-btn i {
        color: #e74c3c;
    }

    .modal {
        display: none;
        position: fixed;
        z-index: 10;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        overflow: auto;
        background-color: rgba(0,0,0,0.4);
        padding-top: 100px;
    }

    .modal-content {
        background-color: #fff;
        margin: auto;
        padding: 25px;
        border-radius: 10px;
        width: 400px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.2);
        text-align: center;
    }

    .close {
        color: #aaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
        cursor: pointer;
    }

    .close:hover, .close:focus {
        color: black;
    }

    .status-symbol {
        font-size: 18px;
    }

    .status-symbol.true {
        color: green;
    }

    .status-symbol.false {
        color: red;
    }

    p {
        text-align: center;
        margin-top: 40px;
    }

    .search-container {
        text-align: center;
        margin: 30px 0;
    }

    .search-container input[type="text"] {
        padding: 10px 14px;
        border: 1px solid #ccc;
        border-radius: 6px;
        width: 250px;
        font-size: 16px;
        outline: none;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }

    .search-container button {
        padding: 10px 16px;
        background-color: #4A90E2;
        color: white;
        border: none;
        border-radius: 6px;
        margin-left: 8px;
        cursor: pointer;
        font-size: 16px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.2);
    }

    .search-container button:hover {
        background-color: #357ABD;
    }

    .back-button {
        background-color: #6c757d;
        color: white;
        border: none;
        padding: 10px 20px;
        font-size: 15px;
        border-radius: 6px;
        cursor: pointer;
        box-shadow: 0 2px 4px rgba(0,0,0,0.2);
        transition: background-color 0.3s ease;
    }

    .back-button:hover {
        background-color: #357ABD;
    }
    
    .modal-content button[type="submit"] {
        background-color: #28a745;
        color: white;
        border: none;
        padding: 10px 20px;
        margin-right: 10px;
        border-radius: 6px;
        font-size: 16px;
        cursor: pointer;
        transition: background-color 0.3s ease, box-shadow 0.2s ease;
        box-shadow: 0 2px 4px rgba(0,0,0,0.2);
    }

    .modal-content button[type="submit"]:hover {
        background-color: #218838;
        box-shadow: 0 4px 8px rgba(0,0,0,0.25);
    }

    .modal-content button[type="button"] {
        background-color: #dc3545;
        color: white;
        border: none;
        padding: 10px 20px;
        border-radius: 6px;
        font-size: 16px;
        cursor: pointer;
        transition: background-color 0.3s ease, box-shadow 0.2s ease;
        box-shadow: 0 2px 4px rgba(0,0,0,0.2);
    }

    .modal-content button[type="button"]:hover {
        background-color: #c82333;
        box-shadow: 0 4px 8px rgba(0,0,0,0.25);
    }
    
    .modal-content select {
    width: 100%;
    padding: 10px 12px;
    border: 1px solid #ccc;
    border-radius: 6px;
    font-size: 16px;
    background-color: #f4f6f8;
    color: #333;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    appearance: none;
    background-image: url('data:image/svg+xml;charset=US-ASCII,<svg xmlns="http://www.w3.org/2000/svg" width="10" height="6" viewBox="0 0 10 6"><path fill="%234A90E2" d="M0 0l5 6 5-6z"/></svg>');
    background-repeat: no-repeat;
    background-position: right 10px center;
    background-size: 10px 6px;
}

.modal-content select:focus {
    outline: none;
    border-color: #4A90E2;
    box-shadow: 0 0 0 3px rgba(74, 144, 226, 0.2);
}
    
</style>
</head>
<body>
<h2>Order Form</h2>

<div class="search-container">
    <form id="searchForm" method="get" action="ProductController">
        <input type="text" name="search_order_id" placeholder="Enter Order ID" required />
        <button type="submit" name="action" value="search_status">Search Status</button>
    </form>
</div>

<%
    List<ProductPojo> orders = (List<ProductPojo>) request.getAttribute("ordersList");
    if (orders != null && !orders.isEmpty()) {
%>
    <table>
        <tr>
            <th>Order ID</th>
            <th>Product ID</th>
            <th>Consumer Port ID</th>
            <th>Quantity</th>
            <th>Order Date</th>
            <th>Order Placed</th>
            <th>Shipped</th>
            <th>Out for Delivery</th>
            <th>Delivered</th>
            <th>Actions</th>
        </tr>
        <% for (ProductPojo order : orders) { %>
        <tr>
            <td><%= order.getOrder_id() %></td>
            <td><%= order.getProduct_id() %></td>
            <td><%= order.getConsumer_port_id() %></td>
            <td><%= order.getQuantity() %></td>
            <td><%= order.getOrder_date() %></td>
            <td class="status-symbol <%= order.isOrder_placed() ? "true" : "false" %>"><%= order.isOrder_placed() ? "✅" : "❌" %></td>
            <td class="status-symbol <%= order.isShipped() ? "true" : "false" %>"><%= order.isShipped() ? "✅" : "❌" %></td>
            <td class="status-symbol <%= order.isOut_for_delivery() ? "true" : "false" %>"><%= order.isOut_for_delivery() ? "✅" : "❌" %></td>
            <td class="status-symbol <%= order.isDelivered() ? "true" : "false" %>"><%= order.isDelivered() ? "✅" : "❌" %></td>
            <td>
                <button class="edit-btn" onclick="openUpdateModal('<%= order.getOrder_id() %>')" title="Edit" type="button">
                    <i class="fa fa-pencil"></i>
                </button>
                <form method="post" action="ProductController" style="display:inline;" onsubmit="return confirm('Delete order <%= order.getOrder_id() %>?');">
                    <input type="hidden" name="order_id" value="<%= order.getOrder_id() %>" />
                    <button type="submit" name="action" value="nullnulldeletenull" class="delete-btn" title="Delete">
                        <i class="fa fa-trash"></i>
                    </button>
                </form>
            </td>
        </tr>
        <% } %>
    </table>
<% } else { %>
    <p>No orders found.</p>
<% } %>

<%
    String searchedOrder = request.getParameter("search_order_id");
    if (searchedOrder != null && !searchedOrder.trim().isEmpty()) {
%>
    <div style="text-align: center; margin: 20px;">
        <form method="get" action="ProductController">
            <button type="submit" name="action" value="show" class="back-button">Back</button>
        </form>
    </div>
<%
    }
%>

<!-- Modal for Status Update -->
<div id="updateModal" class="modal">
  <div class="modal-content">
    <span class="close" onclick="closeUpdateModal()">&times;</span>
    <h3>Update Order Status</h3>
    <form method="post" action="ProductController">
        <input type="hidden" name="order_id" id="modal_order_id" />
        
        <label for="status_name">Select Status to Update:</label><br>
        <select name="status_name" id="status_name" required>
            <option value="shipped">Shipped</option>
            <option value="out_for_delivery">Out for Delivery</option>
            <option value="delivered">Delivered</option>
        </select>
        <br><br>
        
        <label for="status_value">Set Status To:</label><br>
        <select name="status_value" id="status_value" required>
            <option value="true">✅ True</option>
            <option value="false">❌ False</option>
        </select>
        <br><br>
        
        <button type="submit" name="action" value="nullupdatenullnull">Update Status</button>
        <button type="button" onclick="closeUpdateModal()">Cancel</button>
    </form>
  </div>
</div>

<%
    String successMessage = (String) request.getAttribute("successMessage");
    if (successMessage != null) {
%>
<div id="successModal" class="modal" style="display:block;">
  <div class="modal-content" style="width: 300px;">
    <span class="close" onclick="closeSuccessModal()">&times;</span>
    <p><%= successMessage %></p>
  </div>
</div>
<script>
    function closeSuccessModal() {
        document.getElementById('successModal').style.display = 'none';
        window.location.href = 'ProductController?action=show';
    }
</script>
<% } %>

<script>
    function openUpdateModal(order_id) {
        document.getElementById('modal_order_id').value = order_id;
        // Reset selects to defaults
        document.getElementById('status_name').selectedIndex = 0;
        document.getElementById('status_value').selectedIndex = 0;
        document.getElementById('updateModal').style.display = "block";
    }

    function closeUpdateModal() {
        document.getElementById('updateModal').style.display = "none";
    }

    window.onclick = function(event) {
        const modal = document.getElementById('updateModal');
        if (event.target === modal) {
            closeUpdateModal();
        }
    }
</script>
</body>

</html>